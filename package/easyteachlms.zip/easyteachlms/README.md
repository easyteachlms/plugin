# EasyTeach LMS

## Installation
1. Upload plugin to WordPress powered site. 
2. 