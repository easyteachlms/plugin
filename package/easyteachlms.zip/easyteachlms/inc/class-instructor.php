<?php
// This will establish a new user role called instructor, they will have editor access. This will also extend instructor capabilites to administrators as well.
