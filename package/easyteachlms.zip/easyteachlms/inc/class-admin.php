<?php
namespace EasyTeachLMS;

class Admin {
    // Register Teacher role
    // Register Student role
    // Cohorts?
}