import { Fragment } from '@wordpress/element';

const General = ({ children }) => {
    return <Fragment>{children}</Fragment>;
};

export default General;
